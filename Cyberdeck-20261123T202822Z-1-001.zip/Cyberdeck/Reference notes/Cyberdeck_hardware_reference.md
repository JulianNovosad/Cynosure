# Cyberdeck — hardware and wiring reference
Updated: 2026-11-23 (Europe/Amsterdam)

## Hardware inventory (mentioned or photographed)
- Raspberry Pi 5, with SunFounder Fusion HAT+ (pictured; HAT's 40-pin connector and expansion interfaces).
- SunFounder Robot HAT (mentioned as an additional component; revision/installed position not independently verified).
- PCA9685 PWM servo driver (mentioned; may overlap functionally with installed HATs).
- SF006C and MG996 servo devices (mentioned; models and electrical specifications to confirm).
- Raspberry Pi Camera Module 3 (mentioned).
- Coral Edge TPU units: four M+B key single-core units owned, with only one usable at a time in the present planned configuration; adapter and power/PCIe details require verification.
- Battery pack (mentioned, model and electrical rating not supplied).
- Display planned through phone over wired Ethernet; keyboard planned as 60% or custom.
- BNO08x-family 9-axis IMU breakout: purple PCB photographed front and rear. Exact BNO080 vs BNO085 chip model and voltage-handling variant not independently verified.
- M01 50M laser distance sensor module: green narrow PCB, black optical housing, four factory-soldered wires. Exact physical match to user's AliExpress product page images and documentation.

## M01 50M laser rangefinder — SOURCE-VERIFIED SELLER DOCUMENTATION
Source: user-uploaded AliExpress listing text `Pasted text(20261123-173122).txt`, `doc.pdf`, and original listing https://nl.aliexpress.com/item/1005009250844924.html . Product photo and pin legend on listing PDF page 8; six-pad pin map on page 10.
- Manufacturer/listing model: M01 50M laser range module.
- Range: ideal 0.2–50 m; typical indoor 0.2–15 m; outdoor sunlight degrades performance.
- Accuracy: listing marketing image claims ±2 mm; detailed seller instructions specify ±5–50 mm for short-range static indoor measurements. Treat published specifications as inconsistent, not as independently verified measurement performance.
- Laser: visible red 650 nm, not infrared 905 nm. Avoid exposure to eyes.
- Electrical: 2.5–3.3 V DC, minimum 150 mA stable source. Seller calls for an independent regulated 3.3 V supply rather than relying on microcontroller 3.3 V output. NEVER connect 5 V.
- Interface: 3.3 V logic UART, 9600 baud, 8 data bits, no parity, one stop bit (8N1).
- Factory four-wire colors on seller's matching product image: RED = MIN (3.3 V supply), BLACK = GND, GREEN = module RXD, YELLOW = module TXD.
- Module TXD (yellow) -> Raspberry Pi UART RX (GPIO15), module RXD (green) -> Raspberry Pi UART TX (GPIO14). Common GND with regulated power source and HAT.
- Six-pad PCB map shown by listing: MIN, ENA, GND, RXD, TXD, NC. ENA may not have an internal pull-up on some four-wire variants. Seller says hold ENA at 3.3 V in normal operation. Confirm pad orientation on original PCB before soldering and before applying power. Do not assume the existing four-wire hookup already powers ENA.
- Commands (hex): single shot AA 00 00 20 00 01 00 00 21 ; continuous AA 00 00 21 00 01 00 00 22.
- Reply length: 12 bytes, verify framing/checksum before decoding. Original example code from seller is machine-translated into Dutch and is NOT executable as pasted.
- Supplier troubleshooting: `EE 00 00 00` indicates invalid/no laser echo; check ENA, supply current, target reflectivity and environment.
- Document discrepancy: some included generic PDF tables may reference additional variants/alternate connectors; prefer the listing's annotated four-wire photo and actual physical PCB over colors from unrelated devices.

## BNO08x IMU breakout (photographed)
- Back of breakout shows pin labels, top to bottom as photographed: `VCC_3V3`, `GND`, `SCL/SCK/RX`, `SDA/MISO/TX`, `ADDR/MOSI`, `CS`, `INT`, `RST`, `PS1`, `PS0`.
- Basic I2C wiring intended: breakout VCC_3V3 -> regulated 3.3V; GND -> common GND; SCL -> Pi I2C SCL (GPIO3), SDA -> Pi I2C SDA (GPIO2), through Fusion HAT+ exposed I2C connection as documented. Never 5 V on 3.3 V breakout.
- Exact breakout chip variant, address-select wiring, PS0/PS1 default pull network and I2C power budget should be verified against the actual PCB revision before turning on.
- Typical BNO08x address options 0x4A/0x4B, but verify board-specific ADDR configuration and attached HAT bus conflicts.
- The black round plastic disc near the breakout in the first photo appears to be a servo horn, not part of the IMU.

## SunFounder Fusion HAT+ and serial buses
Official documentation: https://docs.sunfounder.com/projects/fusion-hat/en/latest/hardware/interfaces.html
- I2C data SDA on Pi GPIO2, clock SCL on GPIO3; IMU belongs on the I2C bus.
- UART from Pi GPIO14 (TXD) and GPIO15 (RXD); laser rangefinder belongs on the UART bus.
- Verify header silk-screen on the actual Fusion HAT+ before attaching female Dupont leads; never assume connector pin order.
- Power the laser from a separate, suitable 3.3 V regulator capable of >150 mA, and join regulator GND with the Pi/Fusion HAT GND.
- Configure serial port using `sudo raspi-config`: disable serial login console and enable hardware serial; use `ls -l /dev/serial0` to verify mapping.
- Quick safe UART smoke test after checking power and wiring: send the single-measurement command via Python pyserial at 9600 baud and inspect hex response; don't assume decoded distances are valid until packet framing and checksum verified.
- To inspect I2C devices: `sudo apt install i2c-tools` followed by `sudo i2cdetect -y 1` after verifying that the Pi 5 interface is enabled and correctly connected.

## Laser reference Python script (raw frame capture, does not misinterpret distance)
```
import serial
with serial.Serial('/dev/serial0', 9600, timeout=2) as port:
    port.reset_input_buffer()
    port.write(bytes.fromhex('AA 00 00 20 00 01 00 00 21'))
    print(port.read(12).hex(' '))
```
Note: `/dev/serial0` must exist and refer to the intended GPIO UART. Use the appropriate venv and install `pyserial`; enable hardware UART and disable console as needed. A returned frame requires protocol validation.

## Open issues / integration checks
1. Confirm exact BNO08x IMU board part number and protocol-mode strap settings before full wiring.
2. Check 3.3 V regulator model, regulator capacity, grounding and available rail voltage under load.
3. Inspect M01 ENA pad at magnification and continuity-check before any soldering.
4. Verify Fusion HAT+ UART header pin order on its actual PCB, and check whether another device/software is using the UART.
5. Check specific Robot HAT/Fusion HAT power-sharing and battery charging advice in official revision-specific docs before connecting battery and charger simultaneously.
6. Inventory the exact Coral M.2 adapters and Pi 5 PCIe arrangement; do not assume all four can be used concurrently.

## Original external references
- M01 AliExpress listing: https://nl.aliexpress.com/item/1005009250844924.html
- M01 related community example (not authoritative relative to seller): https://github.com/Andres-ros/laser-m01-esp32
- SunFounder Fusion HAT+ interfaces: https://docs.sunfounder.com/projects/fusion-hat/en/latest/hardware/interfaces.html
- SunFounder Fusion HAT+ I2C: https://docs.sunfounder.com/projects/fusion-hat/en/latest/project/i2c.html
- BNO08x family general datasheet: https://cdn.sparkfun.com/assets/0/3/9/6/4/BNO080_Datasheet_v1.3.pdf

## Included local source file key
- `doc.pdf`: complete uploaded AliExpress listing printout (16 pages)
- `Pasted text(20261123-173122).txt`: copied product specifications, warnings and UART commands
- `1000063421.jpg`: first Fusion HAT+ and IMU overview
- `image-1795454021167.jpg`, `image-1795454045673.jpg`: IMU front/back labels
- `image-1795454573681.jpg`, `image-1795454580782.jpg`: M01 laser PCB front/back and cable
- Additional cropped and enlarged views are derived support images, not independent sources.
